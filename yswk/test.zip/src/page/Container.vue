<template>
  <div class="container">
    <div class="header">
      <div class="title">
        海康威视实习生编程题<img class="img" src="" />
      </div>
    </div>
    <Tip class="tip"></Tip>
    <Question></Question>
    <Radio></Radio>
    <MultiRadio></MultiRadio>
    <div class="footer">
      <input type="button" value="提交" class="submitBtn"/>
    </div>
    <div class="bottom">
      <hr/>
      问卷星 提供技术支持
    </div>
  </div>
</template>
<script>
import Question from '@/components/Question'
import Tip from '@/components/Tip'
import Radio from '@/components/Radio'
import MultiRadio from '@/components/MultiRadio'
export default {
  components: {
    Tip,
    Question,
    Radio,
    MultiRadio
  }
}
</script>
<style scoped>
.container {
  width: 70vw;
  height: auto;
  margin-top: 100px;
  padding-bottom: 20px;
  /* position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%); */
  text-align: left;
  background-color: rgba(24,24,24,0.1);
  border-radius: 5px;
}
.header {
  display: inline;
  /* flex-direction: ; */
}
.title {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  color: #0095ff;
  padding:15px 0;
}
.img{
  float: right;
  width: 50px;
  height: 50px;
  background-color: yellow;
}
.tip {
  margin: 0 80px;
}
.submitBtn{
  background-color:#0095ff;
  color: white;
  outline: none;
  width: 82px;
  height: 32px;
  font-size: 16px;
  border: none;
  border-radius: 1px;
}
.submitBtn:hover{
  background-color: blue;
}
.footer {
  text-align: center;
}
.bottom {
  text-align: center;
}
</style>
