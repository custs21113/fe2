<template>
  <div class="tt-test">
    <div class="question"><p>*</p><p>{{question}}</p></div>
    <div>
      <ul v-for="(item, id) in items" v-bind:key="id">
        <label>
          <li >
            <input type="checkbox" v-model="item.checked"/>{{item.name}}
          </li>
        </label>
      </ul>
      <div class="result">您已经选择了{{selectItemCount}}项，<a>少选择了{{max-selectItemCount}}项</a></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TTest',
  props: ['items', 'question', 'max', 'min'],
  data () {
    return {
    }
  },
  computed: {
    selectItemCount () {
      let count = this.items.filter(item => item.checked)
      if (count.length > this.max) {
        alert('超出')
      }
      return count.length
    }
  },
  watch: {
    moreThanMax: function () {
      let count = this.items.filter(item => item.checked)
      if (count > this.max) {
        alert('超出')
      }
    }
  }
}
</script>

<style scoped>
  .tt-test{
    width:inherit;
    margin-left: 80px;
  }
  .tt-test p{
    font-weight: bold;
  }
  .question {
    display:inline-flex;
  }
  p:first-of-type {
    color:red;
  }
  ul {
    width: inherit;
    display: inline-flex;
    list-style: none;
    flex-wrap: wrap;
  }
  label {
  margin-left:-3vw;
    width: 400px;
    flex-basis: 400px;
  }
  li:hover{
    background-color: grey;
  }
  .result a {
    color: red;
  }
</style>
