<template>
<div>
  <div class="multiRadio">
    <div style="width: 100%" >
      <a>*</a>
      <a>您现在的年级是</a>
      <div></div>
      <ul v-for="(item, index) in items" v-bind:key="index">
        <label>
        <li>
           <input type="radio" v-model="question3" name="question3" :value="item.value" />{{item.grade}}
        </li>
        </label>
      </ul>
    </div>
  </div>
  <TTest v-show="question3===5||question3===6" :items="childItems" :question="question" :max="max" :min="min">dddd</TTest>
</div>
</template>
<script>
import TTest from '@/components/TTest'
export default {
  name: 'MultiRadio',
  components: {
    TTest
  },
  data () {
    return {
      items: [
        {
          value: 1,
          grade: '大一'
        },
        {
          value: 2,
          grade: '大二'
        },
        {
          value: 3,
          grade: '大三'
        },
        {
          value: 4,
          grade: '大四'
        },
        {
          value: 5,
          grade: '硕士'
        },
        {
          value: 6,
          grade: '博士'
        }],
      childItems: [
        {
          id: '1',
          name: 'test',
          checked: false
        },
        {
          id: '2',
          name: 'TT',
          checked: false
        },
        {
          id: '3',
          name: 'TT',
          checked: false
        },
        {
          id: '4',
          name: 'TT',
          checked: false
        },
        {
          id: '5',
          name: 'TT',
          checked: false
        }
      ],
      question: '您在毕业后关于行业优先考虑的因素有？',
      question3: '',
      max: 3,
      min: 1,
      grade: []
    }
  },
  watch: {
    checkedValue: function () {
      this.grade = []
      this.grade.push(this.question3)
    }
  }
}
</script>
<style scoped>
.multiRadio {
  display: flex;
  list-style: none;
  margin: 0px 80px;
  width: inherit;
}
.multiRadio span {
  color: red;
  display: inline;
}
a:first-of-type {
  color: red;
}
.multiRadio a {
  font-weight: bold;
}
label {
  display: block;
  flex-basis: 400px;
  width: 400px;
  margin-left:-3vw;
}
li:hover {
  background: grey;
}
ul {
  width: inherit;
  list-style: none;
  display: inline-flex;
  flex-wrap: wrap;
}
</style>
