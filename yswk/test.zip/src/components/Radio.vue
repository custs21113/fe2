<template>
  <div class="radio">
    <a>* </a>
    <a>您的性别是</a>
    <li>
      <label> <input type="radio" name="question2" value="1" />男 </label>
    </li>
    <li>
      <label> <input type="radio" name="question2" value="2" />女 </label>
    </li>
  </div>
</template>
<script>
export default {
  name: 'Radio',
  data () {
    return {

    }
  }
}
</script>
<style scoped>
span {
  color: red;
}
.radio {
  margin: 0 80px 15px;
  list-style: none;
}
.radio a{
  font-weight: bold;
}
a:first-of-type {
  color: red;
}
label {
  display: block;
}
label:hover{
  background-color: grey;
}
</style>
