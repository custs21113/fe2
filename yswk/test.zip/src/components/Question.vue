<template>
    <div class="question">
      <span>*</span>
      <div>
      姓名: <input v-model="name" type="text"/>
      年龄: <input v-model="age" type="text"/> 岁<br/>
      电话: <input v-model="name" type="text"/>
      </div>
    </div>
</template>
<script>
export default {
  name: 'Question',
  data () {
    return {
      name: '',
      age: '',
      phone: ''
    }
  }
}
</script>
<style scoped>
  span {
    color: red;
    display: inline-block;
    width: 5px;
  }
  input{
    outline: none;
    border: none;
    border-bottom: 1px solid grey;
  }
  .question {
    display: inline-flex;
    margin: 30px 80px;
    font-weight: bold;
  }
</style>
