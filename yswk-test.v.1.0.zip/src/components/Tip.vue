<template>
  <div>
    <span>
      请打开编译器，完成此页面的开发。<br />
      注意：<br />
      1. 使用vue-cli开发。<br />
      2. 如使用css预编译器，请使用less，不要使用sass。<br />
      3. 问题需组件化开发，以达到组件复用的目的。<br />
      4.
      完成后，将源码(除node_modules外)打包压缩，与其他题目答案一起发送至邮箱yuhua7@hikvision.com
    </span>
    <hr />
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
